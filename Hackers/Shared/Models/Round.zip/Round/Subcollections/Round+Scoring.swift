//
//  Round+Scoring.swift
//  Hackers
//
//  Created by Kyle Beard on 8/23/25.
//

import Foundation

enum ScoreBasis: String, Codable {
    case gross, net
}

// MARK: - ScoreEntry (idempotent subcollection under Round)
struct ScoreEntry: FirebaseSubcollectable {
    var id: String                  // Deterministic: h{number}_s{id}_u{unit}
    
    var holeNumber: Int
    var segmentID: String
    var groupID: String
    
    var scoringUnitID: String
    var participantIDs: [String]    // Denormalization for who this score belongs to

    var strokes: Int?               // Gross strokes where nil == unscored
    var value: String?              // Non-stroke scoring value (if it applies)
    var pickedUp: Bool              // Skipped hole, opted to not score
    
    var entryID: String             // ID of the player who entered this score
    
    var createdAt: Time
    var lastUpdatedAt: Time
    var parentCollection: String
    var parentID: String            // ID of the round
    var subcollectionName: String
    
    init(
        id: String = "",
        holeNumber: Int = 0,
        segmentID: String = "",
        groupID: String = "",
        scoringUnitID: String = "",
        participantIDs: [String] = [],
        strokes: Int? = nil,
        value: String? = nil,
        pickedUp: Bool = false,
        entryID: String = "",
        createdAt: Time = .init(),
        lastUpdatedAt: Time = .init(),
        parentCollection: String = Collections.rounds.rawValue,
        parentID: String = "",
        subcollectionName: String = RoundSubcollection.scores.rawValue
    ) {
        self.id = id
        self.holeNumber = holeNumber
        self.segmentID = segmentID
        self.groupID = groupID
        self.scoringUnitID = scoringUnitID
        self.participantIDs = participantIDs
        self.strokes = strokes
        self.value = value
        self.pickedUp = pickedUp
        self.entryID = entryID
        self.createdAt = createdAt
        self.lastUpdatedAt = lastUpdatedAt
        self.parentCollection = parentCollection
        self.parentID = parentID
        self.subcollectionName = subcollectionName
    }
    
    enum CodingKeys: String, CodingKey {
        case id, strokes, value
        case holeNumber = "hole_number"
        case segmentID = "segment_id"
        case groupID = "group_id"
        case scoringUnitID = "scoring_unit_id"
        case participantIDs = "participant_ids"
        case pickedUp = "picked_up"
        case entryID = "entry_id"
        case createdAt = "created_at"
        case lastUpdatedAt = "last_updated_at"
        case parentCollection = "parent_collection"
        case parentID = "parent_id"
        case subcollectionName = "subcollection_name"
    }
}

extension ScoreEntry {
    static func makeID(hole: Int, segment: String, scoringUnit: String) -> String {
        "h\(hole)_s\(segment)_u\(scoringUnit)"
    }
}

// MARK: - Scoring Unit (linked to RoundSegment)
struct ScoringUnit: Hashable, Codable, Identifiable {
    /// Unique ID for this scoring unit
    var id: String
    
    /// Who shares this score (1+ players)
    var participants: [String]
    
    /// Optional: "Team Red", "Pair 1", player name
    var name: String?
    
    /// Optional: For team competitions (Ryder Cup)
    var teamID: String?
    
    /// Individual scoring or aggregate of multiple participants/
    var scoringMethod: ScoringMethod
    
    /// How scores are condensed or represented (if participants.count > 1)
    var aggregation: Aggregation?
    
    /// Adjust inputted handicap index based on game format (playerID mapped to adjusted handicap)
    var handicapAdjustments: [String: Double]?

    init(
        id: String = "",
        participants: [String] = [],
        name: String? = nil,
        teamID: String? = nil,
        scoringMethod: ScoringMethod = .individual,
        aggregation: Aggregation? = nil,
        handicapAdjustments: [String : Double]? = nil
    ) {
        self.id = id
        self.participants = participants
        self.name = name
        self.teamID = teamID
        self.scoringMethod = scoringMethod
        self.aggregation = aggregation
        self.handicapAdjustments = handicapAdjustments
    }
    
    enum CodingKeys: String, CodingKey {
        case id, name, participants, aggregation
        case teamID = "team_id"
        case scoringMethod = "scoring_method"
        case handicapAdjustments = "handicap_adjustments"
    }
    
    var isIndividual: Bool { participants.count == 1 }
    var displayName: String { name ?? (isIndividual ? "Individual" : "Team") }
}

enum ScoringMethod: String, Codable {
    case individual           // one participant per unit
    case aggregate            // team aggregate (sum or best-N per hole/round)
}
