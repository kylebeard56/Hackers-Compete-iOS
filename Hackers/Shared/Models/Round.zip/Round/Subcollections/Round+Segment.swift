//
//  Round+Segment.swift
//  Hackers
//
//  Created by Kyle Beard on 8/28/25.
//

import Foundation

struct RoundSegment: FirebaseSubcollectable {
    var id: String
    
    var roundID: String
    var holeRange: HoleRange
    var gameFormat: GameFormat
    var scoringUnits: [ScoringUnit]
    
    var createdAt: Time
    var lastUpdatedAt: Time
    var parentCollection: String
    var parentID: String
    var subcollectionName: String
}
